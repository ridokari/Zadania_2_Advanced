package com.company;

import java.io.File;
import java.util.List;
import java.util.stream.Stream;

public class Strumienie1 {

	public static void main(String[] args) {
		File plik = new File("pracownicy.csv");
		List<Employee> employees = ObslugaCSV.wczytaj(plik);
		
		// Stream<Employee> stream = employees.stream();
		
		System.out.println("stream forEach:");
		employees.stream().forEach(emp -> System.out.println(" * " + emp.getFirstName() + " " + emp.getLastName()));
		System.out.println("\n============\n");
		
		// forEach jest też dostępny bezpośrednio dla list:
		System.out.println("list forEach");
		employees.forEach(emp -> System.out.println(" - " + emp.getFirstName() + " " + emp.getLastName()));
		
		System.out.println("\n============\n");

		// dzięki stream-owi uzyskujemy jednak dostęp do wielu operacji
		
		System.out.println("stream filter forEach:");
		employees.stream()
			.filter(emp -> emp.getSalary() > 10000)
			.forEach(emp -> System.out.println(" + " + emp.getFirstName() + " " + emp.getLastName()));

		System.out.println("\n============\n");
		
		// za pomocą strumieni można łatwo składać rózne przekształcenia danych:
		employees.stream()
			.filter(emp -> emp.getSalary() < 5000)
			.map(emp -> emp.getFirstName() + " " + emp.getLastName())
			.map(String::toUpperCase)
			.forEach(System.out::println);

			// .map(s -> s.toUpperCase())
			// .forEach(s -> System.out.println(s));
		
	}

}
