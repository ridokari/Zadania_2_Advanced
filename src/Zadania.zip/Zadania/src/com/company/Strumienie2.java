package com.company;

import java.io.File;
import java.util.List;
import java.util.stream.Collectors;

public class Strumienie2 {
// nie formatować w Eclipse
	
	public static void main(String[] args) {
		File plik = new File("pracownicy.csv");
		List<Employee> employees = ObslugaCSV.wczytaj(plik);
		
		// Aby policzyć średnią, można skorzystać z gotowego "kolektora"
		double srednia1 = employees.stream()
			.collect(Collectors.averagingInt(Employee::getSalary));
		System.out.println(srednia1);
		
		
		// Można też zmapować strumień obiektów Employee na strumień int-ów, a pojawi się gotowa operacja average.
		// W komentarzu zmiana typu w kolejnych krokach
		double srednia2 = employees.stream() // List<Employee> => Stream<Employee>
			.mapToInt(Employee::getSalary)   // Stream<Employee> => IntStream
			.average()                       // IntStream => OptionalDouble
			.getAsDouble();                  // OptionalDouble => double
		System.out.println(srednia2);
		System.out.println();
		
		
		double srednia3 = employees.stream()
			.filter(emp -> "Programmer".equals(emp.getJobTitle()))
			.collect(Collectors.averagingInt(Employee::getSalary));
		
		System.out.println(srednia3);
	}

}
