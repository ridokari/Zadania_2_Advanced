package com.company;

import java.io.File;
import java.io.FileNotFoundException;
import java.text.Collator;
import java.time.LocalDate;
import java.util.*;
import java.util.stream.Collectors;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;

public class Word {

static Scanner sc;

public static void openFile() {

JButton open = new JButton();
JFileChooser f = new JFileChooser("C:\\Users\\kujap\\Desktop\\pan tadeusz\\");
f.setFileSelectionMode(JFileChooser.FILES_AND_DIRECTORIES);
if (f.showOpenDialog(open) == JFileChooser.APPROVE_OPTION) {

}

System.out.println(f.getSelectedFile().getAbsolutePath());
try {
sc = new Scanner(new File(f.getSelectedFile().getAbsolutePath()));
} catch (Exception e) {
System.out.println("not found");
}

}

public static void readFile() {
int i = 0;
int j = 0;
String wyraz = JOptionPane.showInputDialog("Wybierz wyraz");

while (sc.hasNext()) {
j++;
sc.useDelimiter("[-+*, .…—?»)(«!.;:/#_^\\s]");

String slowo = sc.next();
System.out.println(slowo);

if (slowo.equals(wyraz)) {
i++;
}
}
System.out.println("tadeusz = " + i);
System.out.println("slowa = " + j);
}

public static void closeFile() {
sc.close();
}

private static void TxtToList(List<String> words) {
        String slowo;
        int j =0;
        while (sc.hasNext()) {
            // tu mam problem z delimiterem ponieważ nadal dodaje pusty string
            sc.useDelimiter("[-+*, .…—?»)(«!.;:/#_^\\s]");
            slowo = sc.next();
            // po dodaniu tutaj if udało mi się wyeliminować problem ale nadal chciłąbym wiedzieć jak można to lepiej zrobić delimiterem
            if (!slowo.equals("")) {
                words.add(slowo);
                j++;
            }
        }
    System.out.println(j);
}

private static List<String> getStrings(List<String> words) {
        List<String> words2 = new ArrayList<String>();

        for (String temp : words) {

            if (!words2.contains(temp)) {
                words2.add(temp);
            }
        }
        return words2;
    }

public static void allWords() {
int i=0;
openFile();
List<String> words = new ArrayList<>();

TxtToList(words);
closeFile();
List<String> words2 = getStrings(words);

words2.sort(Collator.getInstance(new Locale("pl", "PL")));

/* for (String temp2 : words2) {
int occurrences = Collections.frequency(words, temp2);

System.out.println(temp2 + " " + occurrences);
}
*/

 List<Words> word = new ArrayList<Words>();
for (String temp2 : words2) {
int occurrences = Collections.frequency(words, temp2);
i++;
word.add(new Words(temp2, occurrences));

}

//word.stream()
  //      .sorted(Comparator.comparingInt(Words::getNumber).reversed());

    //  .forEach(System.out::println);

   // word.stream()
    //        .sorted(Comparator.comparing(Words::getWord));


    System.out.println(i);
    openFile();
    List<Polimorf> polimorfs = new ArrayList<Polimorf>();
    int id=0;
    while(sc.hasNextLine()) {
        String linia = sc.nextLine();
        String[] fragmenty = linia.split("\\t");


        Polimorf pol = new Polimorf(id, fragmenty[0].toLowerCase(), fragmenty[1]);
        id++;
        polimorfs.add(pol);
    }

    polimorfs.stream()
           .sorted(Comparator.comparing(Polimorf::getOdmiana))
    .collect(Collectors.toList());
   // polimorfs.sort(Collator.getInstance(new Locale("pl", "PL")));

    Comparator<Polimorf> c = new Comparator<Polimorf>() {
        public int compare(Polimorf u1, Polimorf u2) {

            return u1.getOdmiana().compareTo(u2.getOdmiana());
        }
    };
    System.out.println(polimorfs.get(3636896));
    System.out.println(polimorfs.get(3636895));
int k = 0;
    System.out.println("wczytano baze");
    for (Words temp: word) {
        String slowo = temp.getWord().toLowerCase();
        System.out.println(slowo);

        int index = Collections.binarySearch(polimorfs, new Polimorf(slowo), c);
       System.out.println(index);



       for (Polimorf temp2 : polimorfs) {
            if (temp.getWord().equals(temp2.getOdmiana())) {
                temp.setWord(temp2.podst);
                System.out.println(k+ " " +temp.getWord());
                k++;
                break;
            }


        }
    }
closeFile();

}




        public static void main(String[] args) {

allWords();
//poli();


}
}

