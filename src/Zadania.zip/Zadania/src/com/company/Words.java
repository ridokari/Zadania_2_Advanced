package com.company;

public class Words {
    String Word;

    public String getWord() {
        return Word;
    }

    public void setWord(String word) {
        Word = word;
    }

    public int getNumber() {
        return number;
    }

    public void setNumber(int number) {
        this.number = number;
    }

    public Words(String word, int number) {
        super();
        Word = word;
        this.number = number;
    }

    int number;

    @Override
    public String toString() {
        return "number= " + number + " " + "\"" + Word + "\"";
    }
}